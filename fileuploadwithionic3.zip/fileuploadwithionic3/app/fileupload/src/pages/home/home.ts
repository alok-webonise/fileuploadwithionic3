import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})


export class HomePage {
	imageURI:any;
  imageFileName:any;

  constructor(public navCtrl: NavController,private transfer: FileTransfer, private file: File) {



  }

   onChange(files) {
    console.log(files);

    this.imageFileName = files.srcElement.files && files.srcElement.files[0]
    this.imageURI = URL.createObjectURL(this.imageFileName)
  }


  uploadFile() {

      let options: FileUploadOptions = {
      fileKey: this.imageFileName && this.imageFileName.name,
      fileName: this.imageFileName && this.imageFileName.name,
      chunkedMode: false,
      mimeType: this.imageFileName && this.imageFileName.name,
      headers: {}
    }
    const fileTransfer: FileTransferObject = this.transfer.create()


  fileTransfer.upload(this.imageURI, 'http://localhost:3000/upload', options)
      .then((data) => {
      console.log(data+" Uploaded Successfully");
    }, (err) => {
      console.log(err);

    });
}

}
